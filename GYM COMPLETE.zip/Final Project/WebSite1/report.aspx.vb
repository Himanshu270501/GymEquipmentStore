﻿Partial Class report
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Label5.Text = Session("email")
        If Session("email") = "" Then
            Label5.Visible = False
            LinkButton1.Visible = False
        Else
            Label5.Visible = True
            LinkButton1.Visible = True
        End If
    End Sub
    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Session.RemoveAll()
        Response.Redirect("home.aspx")
    End Sub

End Class
