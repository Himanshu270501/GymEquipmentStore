﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class changepwd
    Inherits System.Web.UI.Page
    Dim cn As New SqlConnection
    Dim cmd As New SqlCommand

    Protected Sub update_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles update.Click
        cmd = New SqlCommand("update cust_mst set pwd='" + npt.Text + "' where email='" + Label1.Text + "'", cn)
        cmd.ExecuteNonQuery()
        MsgBox("password changed")
        Response.Redirect("login.aspx")

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        exitl.Visible = True
        Label1.Text = Session("email")
        cn = New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Himanshu\TYBCA\WebSite1\App_Data\signup.mdf;Integrated Security=True;User Instance=True")
        cn.Open()
    End Sub

    Protected Sub npt_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles npt.Load
        Show.Visible = True
    End Sub
    Protected Sub Show_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Show.Click
        npt.TextMode = TextBoxMode.SingleLine
        cpt.TextMode = TextBoxMode.SingleLine
        Show.Visible = False
    End Sub

    Protected Sub exitl_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles exitl.Click
        Session.RemoveAll()
        Response.Redirect("home.aspx")
    End Sub
End Class
