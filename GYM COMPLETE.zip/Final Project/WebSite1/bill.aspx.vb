﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class bill
    Inherits System.Web.UI.Page
    Dim cn As New SqlConnection
    Dim cmd As New SqlCommand
    Dim dr As SqlDataReader
    Dim da As SqlDataAdapter
    Dim ds As New DataSet
    Dim i As Integer

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        cn = New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Himanshu\TYBCA\WebSite1\App_Data\signup.mdf;Integrated Security=True;User Instance=True")
        cn.Open()
        Label5.Text = "Welcome " + Session("email")
        If Session("email") = "" Then
            Label5.Visible = False
            LinkButton1.Visible = False
        Else
            Label5.Visible = True
            LinkButton1.Visible = True

        End If

        Label1.Text = Today


        i = Request.QueryString("billno")

        cmd = New SqlCommand("select * from bill_mst  where billno=" & i, cn)

        dr = cmd.ExecuteReader

        If dr.Read Then
            Label2.Text = dr.Item("billno")
            Label3.Text = dr.Item("name")
            Label4.Text = dr.Item("addr")
            Label6.Text = dr.Item("pincode")
            Label7.Text = dr.Item("total")
        End If
        dr.Close()
        GridView1.Enabled = True



    End Sub

    Protected Sub cnf_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cnf.Click
        cmd = New SqlCommand("delete from cart_mst where ordrsts='yes' and email='" + Session("email") + "'", cn)
        cmd.ExecuteNonQuery()
        Response.Redirect("home.aspx")
    End Sub

    Protected Sub fb_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles fb.Click
        cmd = New SqlCommand("delete from cart_mst where ordrsts='yes' and email='" + Session("email") + "'", cn)
        cmd.ExecuteNonQuery()
        Response.Redirect("feedback.aspx")
    End Sub
End Class
