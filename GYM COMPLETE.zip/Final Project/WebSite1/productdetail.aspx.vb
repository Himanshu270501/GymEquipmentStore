﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class productdetail
    Inherits System.Web.UI.Page
    Dim cn As New SqlConnection
    Dim cmd As New SqlCommand
    Dim dr As SqlDataReader
    Dim da As SqlDataAdapter
    Dim ds As New DataSet
    Dim total As Integer
    Dim qty As Integer
    Dim dr1 As SqlDataReader
    Dim dr2 As SqlDataReader
    Dim drshivam As SqlDataReader
    Dim odrpname As String
    Dim shivamssn As String
    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Session.RemoveAll()
        Response.Redirect("home.aspx")
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        cn = New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Himanshu\TYBCA\WebSite1\App_Data\signup.mdf;Integrated Security=True;User Instance=True")
        cn.Open()
        shivamssn = Session("email")
        Label5.Text = "Welcome " + Session("email")
        If Session("email") = "" Then
            Label5.Visible = False
            LinkButton1.Visible = False
        Else
            Label5.Visible = True
            LinkButton1.Visible = True
        End If
        Dim x As String = Request.QueryString("id")
        cmd = New SqlCommand("select * from product_mst where pid='" + x + "'", cn)
        dr = cmd.ExecuteReader
        If dr.Read Then

            name.Text = dr.Item("pname")
            cat.Text = dr.Item("cat")
            odrpname = dr.Item("pname")

            des.Text = dr.Item("desp")
            price.Text = dr.Item("price")

        End If

        dr.Close()

        cmd = New SqlCommand("select * from product_mst where pid='" + x + "'", cn)
        da = New SqlDataAdapter(cmd)
        da.Fill(ds, "abc")
        DataList1.DataSource = ds.Tables("abc")
        DataList1.DataBind()
    End Sub
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim cid As Integer
        If Session("email") = "" Then
            MsgBox("Please Login first to add the product to cart")
            Response.Redirect("login.aspx")

        End If
        cmd = New SqlCommand("select count(qty) from product_mst where pid='" + Request.QueryString("id") + "'", cn)
        Dim s As Integer = cmd.ExecuteScalar
        If s = 0 Then
            DropDownList1.Enabled = False
            Button1.Enabled = False
            Label4.Visible = True
            Label4.Text = "Out of Stock"
        Else
            cmd = New SqlCommand("select count (pid) from cart_mst where pid='" + Request.QueryString("id") + "' and email='" + Session("email") + "'", cn)
            dr1 = cmd.ExecuteReader()




            If dr1.Read = True Then
                dr1.Close()
                cmd = New SqlCommand("select * from cart_mst where pid='" + Request.QueryString("id") + "' and email='" + Session("email") + "'", cn)
                dr = cmd.ExecuteReader()


                If dr.Read Then
                    qty = dr.Item("qty") + DropDownList1.SelectedValue
                    total = qty * price.Text
                    dr.Close()

                    cmd = New SqlCommand("update cart_mst set qty=" & qty & " ,total=" & total & " where email='" + Session("email") + "' and pid='" + Request.QueryString("id") + "'", cn)
                    cmd.ExecuteNonQuery()
                    MsgBox("Epuipment added to cart")
                    Response.Redirect("cart.aspx")

                End If
            End If

            Call prtotal()
            dr.Close()

            Dim shivamquery As String
            shivamquery = "select cid from cust_mst where email= '" + shivamssn + "'"
            cmd = New SqlCommand(shivamquery, cn)
            drshivam = cmd.ExecuteReader()
            If drshivam.Read Then

                cid = drshivam.GetValue(0)

            End If
            drshivam.Close()

            Dim x As String = Request.QueryString("id")
            cmd = New SqlCommand("select * from product_mst where pid='" + x + "'", cn)
            dr2 = cmd.ExecuteReader()

            If dr2.Read Then
                dr2.Close()
                Dim odrid As String
                odrid = odrpname + x.ToString + cid.ToString
                Dim iqu As String = "insert into cart_mst values('" + odrid + "','" + x + "','" + DropDownList1.SelectedValue + "','" + Session("email") + "'," & total & ",'no')"
                cmd = New SqlCommand(iqu, cn)

                MsgBox(iqu.ToString)

                cmd.ExecuteNonQuery()

                MsgBox("Equipment added to cart")
                Response.Redirect("cart.aspx")

            End If


        End If
    End Sub
    Public Sub prtotal()
        total = DropDownList1.SelectedValue * price.Text
    End Sub

End Class
