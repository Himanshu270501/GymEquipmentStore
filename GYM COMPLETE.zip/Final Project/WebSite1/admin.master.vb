﻿
Partial Class admin
    Inherits System.Web.UI.MasterPage
End Class

