﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class Dumbells
    Inherits System.Web.UI.Page
    Dim cn As New SqlConnection
    Dim cmd As New SqlCommand
    Dim da As SqlDataAdapter
    Dim ds As New DataSet
    Dim x As String = "Dumbells"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        usern.Text = "Welcome " + Session("email")
        If Session("email") = "" Then
            usern.Visible = False
            LinkButton1.Visible = False
        Else
            usern.Visible = True
            LinkButton1.Visible = True
        End If

        cn = New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Himanshu\TYBCA\WebSite1\App_Data\signup.mdf;Integrated Security=True;User Instance=True")
        cn.Open()

        cmd = New SqlCommand("select * from product_mst where cat='" + x + "' ", cn)
        da = New SqlDataAdapter(cmd)
        da.Fill(ds, "abc")
        DataList1.DataSource = ds.Tables("abc")
        DataList1.DataBind()
    End Sub
    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Session.RemoveAll()
        Response.Redirect("home.aspx")
    End Sub

    Protected Sub DataList1_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataListCommandEventArgs) Handles DataList1.ItemCommand
        If e.CommandName = "abc" Then
            Response.Redirect("productdetail.aspx?id=" & e.CommandArgument)
        End If
    End Sub
End Class
