﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class feedback
    Inherits System.Web.UI.Page
    Dim cn As New SqlConnection
    Dim cmd As New SqlCommand

    Protected Sub cancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cancel.Click
        Response.Redirect("home")
    End Sub

    Protected Sub submit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles submit.Click
        If email.Text = "" Then
            MsgBox("Please enter your email id")
        End If
        Dim l As String = ""
        If price.Checked = True Then
            l = "Price"
        End If
        If products.Checked = True Then
            l = l + "," + "Products"
        End If
        If brands.Checked = True Then
            l = l + "," + "Brands"
        End If

        Dim s As String = ""
        If bad.Checked = True Then
            s = "Bad"
        End If
        If average.Checked = True Then
            s = "Average"
        End If
        If good.Checked = True Then
            s = "Good"
        End If
        If verygood.Checked = True Then
            s = "Very Good"
        End If
        If excellent.Checked = True Then
            s = "Excellent"
        End If

        Dim r As Integer
        If Rate1.Checked = True Then
            r = 1
        End If
        If Rate2.Checked = True Then
            r = 2
        End If
        If Rate3.Checked = True Then
            r = 3
        End If
        If Rate4.Checked = True Then
            r = 4
        End If
        If Rate5.Checked = True Then
            r = 5
        End If


        cmd = New SqlCommand("insert into feedback values('" + email.Text + "','" + l + "','" + s + "','" & r & "')", cn)
        cmd.ExecuteNonQuery()
        MsgBox("Thanks for your valuable feedback", MsgBoxStyle.Information)
        Response.Redirect("home.aspx")
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        cn = New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Himanshu\TYBCA\WebSite1\App_Data\signup.mdf;Integrated Security=True;User Instance=True")
        cn.Open()
        Label2.Text = "Welcome " + Session("email")
        If Session("email") = "" Then
            Label2.Visible = False
            LinkButton1.Visible = False
        Else
            Label2.Visible = True
            LinkButton1.Visible = True
        End If
    End Sub
    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Session.RemoveAll()
        Response.Redirect("home.aspx")
    End Sub
End Class
