﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class signup
    Inherits System.Web.UI.Page
    Dim cn As New SqlConnection
    Dim cmd As New SqlCommand
    Public Sub clear()
        fnt.Text = ""
        lnt.Text = ""
        addr.Text = ""
        email.Text = ""
        pwd.Text = ""
        phn.Text = ""
        rpwd.Text = ""

    End Sub
    Protected Sub rb_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rb.Click

        Call clear()
       
    End Sub

    Protected Sub sb_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles sb.Click
        cmd = New SqlCommand("insert into cust_mst values('" + fnt.Text + "','" + lnt.Text + "','" + pwd.Text + "','" + addr.Text + "','" & Val(phn.Text) & "','" + email.Text + "','" + DropDownList1.SelectedItem.Text + "','" + ans.Text + "')", cn)
        cmd.ExecuteNonQuery()
        Call clear()
        MsgBox("Sucessfully Registered")
        Response.Redirect("login.aspx")
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        cn = New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Himanshu\TYBCA\WebSite1\App_Data\signup.mdf;Integrated Security=True;User Instance=True")
        cn.Open()

    End Sub

    Protected Sub email_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles email.TextChanged

    End Sub
End Class
