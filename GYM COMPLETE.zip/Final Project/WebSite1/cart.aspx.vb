﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class cart
    Inherits System.Web.UI.Page
    Dim cn As New SqlConnection
    Dim cmd As New SqlCommand
    Dim dr As SqlDataReader

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Label1.Text = "Welcome " + Session("email")
        If Session("email") = "" Then
            Label1.Visible = False
            LinkButton1.Visible = False
            GridView1.Visible = False
            pur.Visible = False
            Label5.Visible = False
            Label6.Visible = False
        Else
            GridView1.Visible = True
            pur.Visible = True
            Label5.Visible = True
            Label6.Visible = True

            Label1.Visible = True

            LinkButton1.Visible = True
            cn = New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Himanshu\TYBCA\WebSite1\App_Data\signup.mdf;Integrated Security=True;User Instance=True")
            cn.Open()

            If GridView1.Rows.Count > 0 Then

                cmd = New SqlCommand("select sum(total) from cart_mst where email='" + Session("email") + "'", cn)
                Label5.Text = cmd.ExecuteScalar
                Label2.Visible = False
                Label8.Visible = True
                Label7.Visible = True
                cmd = New SqlCommand("select count(*) from cart_mst  where email='" + Session("email") + "'", cn)
                Label7.Text = cmd.ExecuteScalar
            Else
                Label2.Visible = True
                Label2.Text = "No products in your cart"
                pur.Visible = False
                Label5.Visible = False
                Label6.Visible = False
            End If
        End If



    End Sub
    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Session.RemoveAll()
        Response.Redirect("home.aspx")
    End Sub

    Protected Sub GridView1_RowDeleted(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeletedEventArgs) Handles GridView1.RowDeleted
        Response.Redirect("cart.aspx")
    End Sub

    Protected Sub GridView1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView1.SelectedIndexChanged

    End Sub

    Protected Sub pur_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles pur.Click
        Dim i As Integer
        cmd = New SqlCommand("select count(*) from bill_mst", cn)
        dr = cmd.ExecuteReader()
        If dr.Read Then

            i = dr.GetValue(0)
        End If
        i += 1
        dr.Close()

        cmd = New SqlCommand("update cart_mst set oid=" & i & ",ordrsts='yes' where email='" + Session("email") + "' and ordrsts='no'", cn)
        cmd.ExecuteNonQuery()
        Response.Redirect("order.aspx?billno=" & i)

    End Sub
End Class
