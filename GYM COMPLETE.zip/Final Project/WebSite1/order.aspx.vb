﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class order
    Inherits System.Web.UI.Page
    Dim cn As New SqlConnection
    Dim cmd As New SqlCommand
    Dim i As Integer
    Dim x As Integer
    Dim dr As SqlDataReader

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        i = Request.QueryString("billno")
        cn = New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Himanshu\TYBCA\WebSite1\App_Data\signup.mdf;Integrated Security=True;User Instance=True")
        cn.Open()
        Label1.Text = "Welcome " + Session("email")
        If Session("email") = "" Then
            Label1.Visible = False
            LinkButton1.Visible = False
        Else
            Label1.Visible = True
            LinkButton1.Visible = True
        End If
    End Sub
    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Session.RemoveAll()
        Response.Redirect("home.aspx")
    End Sub

    Protected Sub bt_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles bt.Click
        If nt.Text = "" Then
            MsgBox("Please enter Name")
        End If
        If adr.Text = "" Then
            MsgBox("Please enter Address")
        End If
        If em.Text = "" Then
            MsgBox("Please enter Email ID")
        End If
        If pn.Text = "" Then
            MsgBox("Please enter Pincode")
        End If
        cmd = New SqlCommand("select sum(total) from cart_mst where oid=" & i, cn)
        x = cmd.ExecuteScalar

        cmd = New SqlCommand("insert into bill_mst values(" & i & ",'" + Today + "','" + nt.Text + "','" + adr.Text + "','" + em.Text + "'," & pn.Text & "," & x & ")", cn)
        cmd.ExecuteNonQuery()
        MsgBox("Order Confirmed")

        Response.Redirect("bill.aspx?billno=" & i)
    End Sub
End Class
