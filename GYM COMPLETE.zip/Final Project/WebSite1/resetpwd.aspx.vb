﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class resetpwd
    Inherits System.Web.UI.Page
    Dim cn As New SqlConnection
    Dim cmd As New SqlCommand
    Dim dr As SqlDataReader

    Protected Sub submit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles submit.Click
        Dim s1 As String = ""
        cmd = New SqlCommand("select * from cust_mst where email='" + email.Text + "'", cn)
        dr = cmd.ExecuteReader()
        If dr.Read() = True Then
            eml.Visible = False
            email.Visible = False
            sq.Visible = True
            ans.Visible = True

            sq.Text = dr.Item("sq").ToString
            If ans.Text = dr.Item("ans").ToString Then
                Session("email") = dr.Item("email")
                Response.Redirect("changepwd.aspx")
                dr.Close()
            Else
                ans.Text = ""
                dr.Close()
            End If
        Else
            MsgBox("email not found")
            email.Text = ""
        End If
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        cn = New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Himanshu\TYBCA\WebSite1\App_Data\signup.mdf;Integrated Security=True;User Instance=True")
        cn.Open()
    End Sub
End Class
