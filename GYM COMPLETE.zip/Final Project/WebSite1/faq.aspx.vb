﻿
Partial Class faq
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Label1.Text = "Welcome " + Session("email")
        If Session("email") = "" Then
            Label1.Visible = False
            LinkButton1.Visible = False
        Else
            Label1.Visible = True
            LinkButton1.Visible = True
        End If
    End Sub
    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Session.RemoveAll()
        Response.Redirect("home.aspx")
    End Sub
End Class
