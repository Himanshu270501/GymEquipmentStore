﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class addproduct
    Inherits System.Web.UI.Page
    Dim cn As New SqlConnection
    Dim cmd As New SqlCommand
    Dim dr As SqlDataReader
    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Session.RemoveAll()
        Response.Redirect("home.aspx")
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Label1.Text = Session("email")
        If Session("email") = "" Then
            Label1.Visible = False
            LinkButton1.Visible = False
        Else
            Label1.Visible = True
            LinkButton1.Visible = True
        End If
        cn = New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Himanshu\TYBCA\WebSite1\App_Data\signup.mdf;Integrated Security=True;User Instance=True")
        cn.Open()

    End Sub
    Protected Sub insert_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles insert.Click
        Dim s1 As String = ""
        If FileUpload1.HasFile Then
            s1 = "product/" + FileUpload1.FileName
            FileUpload1.SaveAs(Server.MapPath("~/product/") + FileUpload1.FileName)
            Dim q As String

            q = "insert into product_mst values('" + pidt.Text + "','" + DropDownList1.SelectedItem.Value + "','" + pnamet.Text + "','" + pricet.Text + "','" + qtyt.Text + "','" + dest.Text + "','" + s1 + "')"

            MsgBox(q)
            cmd = New SqlCommand(q, cn)
            cmd.ExecuteNonQuery()
            MsgBox("Product Inserted")
            Response.Redirect("addproduct.aspx")
        Else
            MsgBox("select any file")
        End If



    End Sub

    Protected Sub GridView1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView1.SelectedIndexChanged
        pidt.Text = GridView1.SelectedRow.Cells(1).Text
        pnamet.Text = GridView1.SelectedRow.Cells(4).Text
        pricet.Text = GridView1.SelectedRow.Cells(3).Text
        qtyt.Text = GridView1.SelectedRow.Cells(5).Text
        FileUpload1.Enabled = False

        cmd = New SqlCommand("select desp from product_mst where pid='" + pidt.Text + "'", cn)
        dr = cmd.ExecuteReader()

        If dr.Read() Then
            dest.Text = dr.Item("desp")
        End If

    End Sub

    Protected Sub clear_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles clear.Click
        Response.Redirect("addproduct.aspx")
    End Sub

    Protected Sub delete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles delete.Click

        cmd = New SqlCommand("delete from product_mst where pid='" + pidt.Text + "'", cn)
        cmd.ExecuteNonQuery()
        MsgBox("Product Deleted")

        Response.Redirect("addproduct.aspx")
    End Sub

    Protected Sub update_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles update.Click
        cmd = New SqlCommand("update product_mst set pname='" + pnamet.Text + "',price='" + pricet.Text + "',qty='" + qtyt.Text + "',desp='" + dest.Text + "' where pid='" + pidt.Text + "'", cn)
        cmd.ExecuteNonQuery()
        MsgBox("Product Updated")
        Response.Redirect("addproduct.aspx")
    End Sub


End Class
